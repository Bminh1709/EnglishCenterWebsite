function deleteConfirm()
{
    if(confirm("Are you sure to delete this course"))
    {
        return true;
    }
    else 
    {
        return false;
    }
}