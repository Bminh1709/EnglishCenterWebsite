<div class="staffs">
    <div class="container section-title-container" ><h2 class="section-title section-title-center"><b></b><span class="section-title-main" style="font-size:110%;color:rgb(21, 74, 152);">Teaching Staff</span><b></b></h2>
</div>

<div style="display:flex; justify-content:space-around; width: 1200px; margin:auto; margin-top:30px;">
    <!-- Profile Image -->
    <div class="card card-primary card-outline" style="width:330px">
    <div class="card-body box-profile">
    <div class="text-center">
        <img class="profile-user-img img-fluid img-circle"
            src="/public/images/img_admin/minhphoto.jpg"
            alt="User profile picture">
    </div>
    <h3 class="profile-username text-center">Bùi Minh</h3>

    <p class="text-muted text-center">Fouder / Teacher</p>

    <ul class="list-group list-group-unbordered mb-3">
        <li class="list-group-item">
            <b>Name</b> <a class="float-right">Mr Bee</a>
        </li>
        <li class="list-group-item">
            <b>Phone</b> <a class="float-right">0706162561</a>
        </li>
        <li class="list-group-item">
            <b>Email</b> <a class="float-right">minhbee203@gmail.com</a>
        </li>
    </ul>
    <a href="https://www.facebook.com/bmint1709/" target="_blank" class="btn btn-primary btn-block btn__green"><b>Contact</b></a>
    </div>
    <!-- /.card-body -->
    </div>
    <!-- /.card -->


    <!-- Profile Image -->
    <div class="card card-primary card-outline" style="width:330px">
    <div class="card-body box-profile">
    <div class="text-center">
        <img class="profile-user-img img-fluid img-circle"
            src="/public/images/img_admin/thuha.jpg"
            alt="User profile picture">
    </div>
    <h3 class="profile-username text-center">Thu Hà</h3>

    <p class="text-muted text-center">CEO / Foreign Teacher</p>

    <ul class="list-group list-group-unbordered mb-3">
        <li class="list-group-item">
            <b>Name</b> <a class="float-right">Ms Misa</a>
        </li>
        <li class="list-group-item">
            <b>Phone</b> <a class="float-right">0706162561</a>
        </li>
        <li class="list-group-item">
            <b>Email</b> <a class="float-right">thuha@gmail.com</a>
        </li>
    </ul>
    <a href="https://www.facebook.com/profile.php?id=100077363162076" target="_blank" class="btn btn-primary btn-block btn__green"><b>Contact</b></a>
    </div>
    <!-- /.card-body -->
    </div>
    <!-- /.card -->


    <!-- Profile Image -->
    <div class="card card-primary card-outline" style="width:330px">
    <div class="card-body box-profile">
    <div class="text-center">
        <img class="profile-user-img img-fluid img-circle"
            src="/public/images/img_admin/tuong.jpg"
            alt="User profile picture">
    </div>
    <h3 class="profile-username text-center">Quang Tường</h3>

    <p class="text-muted text-center">Teacher</p>

    <ul class="list-group list-group-unbordered mb-3">
        <li class="list-group-item">
            <b>Name</b> <a class="float-right">Mr John</a>
        </li>
        <li class="list-group-item">
            <b>Phone</b> <a class="float-right">0706162561</a>
        </li>
        <li class="list-group-item">
            <b>Email</b> <a class="float-right">joinnguyen@gmail.com</a>
        </li>
    </ul>
    <a href="https://www.facebook.com/bui.tuong.104203" target="_blank" class="btn btn-primary btn-block btn__green"><b>Contact</b></a>
    </div>
    <!-- /.card-body -->
    </div>
    <!-- /.card -->

    </div>
</div>