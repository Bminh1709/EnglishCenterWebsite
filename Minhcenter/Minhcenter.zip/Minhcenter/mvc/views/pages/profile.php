
<div class="profile-container">


<?php include "mvc/views/elementsForProfile/profileUser.php"; ?> 
    


<?php include "mvc/views/elementsForProfile/coursesJoined.php"; ?> 



</div>
</div>
