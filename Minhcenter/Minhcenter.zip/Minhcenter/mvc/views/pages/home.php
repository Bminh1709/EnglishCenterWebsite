<img style="height:640px; object-fit:cover;" src="/public/images/toeic3.jpg" class="d-block w-100" alt="...">

<div class="container section-title-container" >
    <h2 class="section-title section-title-center">
        <span class="section-title-main" style="font-size:130%;color:rgb(0, 0, 0);">MB INTERNATIONAL LANGUAGE CENTER</span>
        <div id="courses"></div>
    </h2></div>
<div>
    <p class="title" style="text-align: center;margin-bottom: 20px;"><span style="font-size: 95%;">Trung Tâm Ngoại Ngữ Quốc Tế MB</span></p> 
</div>



<!-- COURSES -->
<?php include "mvc/views/elementsForHome/courses.php"; ?> 
<div id="staffs"></div>



<!-- STAFFS -->
<?php include "mvc/views/elementsForHome/staffs.php"; ?> 
<div id="introduction"></div>



<!-- Introduction -->
<div class="introduction">
  <div class="introduction__left-container">
      <h1 class="troduction--title">BM Center</h1>
      <p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>
      <button class="troduction--btnFindOut"><a class="troduction--btnFindOut__link" href="#introduction">Find out more</a></button>
  </div>
  <div class="introduction__right-container">
      <img class="troduction--img" src="/public/images/teachers.jpg" alt="">
  </div>
</div>



