<!DOCTYPE html>
<html lang="en">
<head>
    <?php include "share/head.php"; ?> 
</head>
<body style="background-color:#f0f1f3;">
    
<?php require_once "./mvc/views/User/".$data["Page"].".php" ?>


</body>
    <?php include "share/footer.php"; ?> 
</html>