<!DOCTYPE html>
<html lang="en">
<head>
    <?php include "share/head.php"; ?> 
</head>
<body class="login-page" style="background-color:#f0f1f3;">
    
<?php require_once "./mvc/views/Admin/".$data["Page"].".php" ?>


</body>
    <?php include "share/footer.php"; ?> 
</html>